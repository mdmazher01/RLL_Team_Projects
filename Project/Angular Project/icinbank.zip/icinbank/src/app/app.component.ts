import { Component } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { AppserviceService } from './appservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'icinbank';
  j: string="";
  //admin
  flag1: boolean=false;//login
  flag2: boolean=true;//logout
  flag3: boolean=false;//reset

  //user
  flag4: boolean=false;//login
  flag5: boolean=true;//logout
  flag6: boolean=false;//reset


  //home 
  flag7: boolean=false;

  //report
  flag8: boolean=true;


  constructor(private app:AppserviceService,private router: Router){
    this.router.events.subscribe((ev) => { //run everytime, whenever componenet change
      if(ev instanceof NavigationEnd){
        this.display2();
      }
    })
  }

  display2(){
    this.j=window.location.href; //j variable store the current component url
    if((this.j=="http://localhost:4200/admindashboard")){
      this.flag2=false;
      this.flag4=true;
      this.flag5=true;
      this.flag6=true;
      this.flag1=true;
      this.flag8=false;
      
    
    }else{
      this.flag2=true;
      this.flag4=false;
      this.flag6=false;
      this.flag1=false;
      this.flag8=true;
      
    }

    if((this.j=="http://localhost:4200/userdashboard")){
        this.flag1=true;
        this.flag3=true;
        this.flag5=false;
        this.flag4=true;
        
    }else{
      this.flag5=true;
      this.flag3=false;
      
     
    }


    if((this.j == "http://localhost:4200/adminreset")){
      this.flag4=true;
      this.flag6=true;
    }
    if((this.j == "http://localhost:4200/userreset")){
        this.flag1=true;
        this.flag3=true;
    }

    if((this.j=="http://localhost:4200/admindashboard") || (this.j=="http://localhost:4200/userdashboard") ){
          this.flag7=true;
    }
    else{
      this.flag7=false;
    }
    if((this.j=="http://localhost:4200/usertable")){
      this.flag8=false;
      this.flag1=true;
      this.flag2=false;
      this.flag3=true;
      this.flag4=true;
      this.flag6=true;
      this.flag7=true;
    }
    
  }
}
